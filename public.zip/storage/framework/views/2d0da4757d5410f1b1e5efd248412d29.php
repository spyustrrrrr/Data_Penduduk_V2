<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header Section -->
    <div>
        <h3 class="text-3xl font-bold text-gray-900">SELAMAT DATANG DI APLIKASI GERGAJI</h3>
        <p class="text-gray-600 mt-2 font-bold">BERANDA</p>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <!-- Card 1: Jumlah Warga -->
        <div class="bg-gradient-to-br from-sky-700 to-sky-800 rounded-2xl shadow-lg p-8 text-white">
            <div class="flex flex-col items-center text-center">
                <h3 class="text-xl font-semibold mb-2">Jumlah Warga</h3>
                <div class="text-6xl font-bold my-4"><?php echo e($totalWarga); ?></div>
            </div>
        </div>

        <!-- Card 2: KK Terdaftar -->
        <div class="bg-gradient-to-br from-sky-700 to-sky-800 rounded-2xl shadow-lg p-8 text-white">
            <div class="flex flex-col items-center text-center">
                <h3 class="text-xl font-semibold mb-2">KK Terdaftar</h3>
                <div class="text-6xl font-bold my-4"><?php echo e($totalKK); ?></div>
            </div>
        </div>

        <!-- Card 3: Jumlah Laki-Laki & Perempuan -->
        <div class="bg-gradient-to-br from-sky-700 to-sky-800 rounded-2xl shadow-lg p-8 text-white">
            <div class="flex flex-col items-center text-center">
                <h3 class="text-xl font-semibold mb-2">Jumlah Laki-Laki</h3>
                <div class="text-6xl font-bold my-4"><?php echo e($totalLaki); ?></div>
            </div>
        </div>
        <div class="bg-gradient-to-br from-sky-700 to-sky-800 rounded-2xl shadow-lg p-8 text-white">
            <div class="flex flex-col items-center text-center">
                <h3 class="text-xl font-semibold mb-2">Jumlah Perempuan</h3>
                <div class="text-6xl font-bold my-4"><?php echo e($totalPerempuan); ?></div>
            </div>
        </div>
    </div>

    <!-- Pengumuman Terkini Section -->
    <div class="bg-gradient-to-br from-sky-700 to-sky-800 rounded-2xl shadow-lg p-8">
        <div class="flex items-center mb-6">
            <div class="bg-sky-100 rounded-3xl p-3 mr-3">
                <i class="fas fa-bullhorn text-sky-800 text-2xl"></i>
            </div>
            <h3 class="text-2xl font-bold text-white">Riwayat Pembaruan</h3>
        </div>

        <div class="bg-white/10 backdrop-blur-sm rounded-xl p-6 space-y-3 max-h-[350px] overflow-y-auto">
            <?php $__empty_1 = true; $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white/20 backdrop-blur-sm rounded-lg p-4 border border-white/30 hover:bg-white/30 transition">
                    <div class="flex items-start gap-3">
                        <!-- Icon berdasarkan action -->
                        <div class="flex-shrink-0 mt-1">
                            <?php if($item['action'] === 'created'): ?>
                                <i class="fas fa-plus-circle text-green-300 text-lg"></i>
                            <?php elseif($item['action'] === 'updated'): ?>
                                <i class="fas fa-edit text-yellow-300 text-lg"></i>
                            <?php elseif($item['action'] === 'deleted'): ?>
                                <i class="fas fa-trash text-red-300 text-lg"></i>
                            <?php endif; ?>
                        </div>
                        
                        <div class="flex-1">
                            <p class="text-white text-sm font-medium"><?php echo e($item['description']); ?></p>
                            <div class="flex items-center gap-3 mt-2 text-xs text-white/80">
                                <span><i class="fas fa-user mr-1"></i><?php echo e($item['user']); ?></span>
                                <span><i class="fas fa-clock mr-1"></i><?php echo e($item['time']); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="bg-white/20 backdrop-blur-sm rounded-lg p-6 border border-white/30 text-center">
                    <i class="fas fa-inbox text-white/50 text-3xl mb-3"></i>
                    <p class="text-white text-sm">Belum ada aktivitas terbaru.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Data_Penduduk_V2\resources\views/dashboard.blade.php ENDPATH**/ ?>